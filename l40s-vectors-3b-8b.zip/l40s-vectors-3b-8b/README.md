# L40S 3B + 8B vector evidence for PR #36

Source: https://github.com/LuxiaSL/anamnesis/commit/34e7fb6c8e46d229f61f23d28e8675eb89cda9fa
PR: https://github.com/LuxiaSL/anamnesis/pull/36

All 44 shipped fixture rows for each model, captured on NVIDIA L40S in three
passes: single-first, single-repeat, and batched. Feature arrays are float32:
3B is 44 x 3358, 8B is 44 x 3414. The models ran float16 and bfloat16 respectively.
These are diagnostic observations: both install checks refused under the
unchanged shipped rules. No tolerance or fixture has been adjusted.

## Read the arrays

Each `<model>/<pass>.npz` contains `generation_ids` (int64 row IDs) and
`vectors` (float32 [rows, features]); load with `numpy.load(..., allow_pickle=False)`.
Always join rows by generation ID. Column order is `feature_names` in
`<model>/reference/fixtures.json`. No normalization or rounding was applied;
auxiliary KNN-LM arrays are omitted.

`<model>/reference/` is an exact copy of the B200 reference fixtures shipped
at the source commit. Its `vectors.npz` includes `generation_ids`, `vectors`,
`sigma_cal`, and `weights`. `fixtures.json` also has token IDs, span boundaries,
row strata, and noise floors. `tolerance.json` carries feature-family mappings
and all recorded ceilings. Each model has its own ruler; compare it against
its corresponding reference, not against the other model's coordinate indices.

`<model>/conformance.json` is the complete original verdict and host fingerprint.
`single-capture.json` and `batched-capture.json` record capture provenance.
`comparison.json` and `OBSERVATIONS.md` contain the detailed findings. Paths in
the original receipts and comparison are provenance labels from the capture VM;
verification below does not open those paths.

## Verify without a GPU or model download

With Python 3.11 or later, from this extracted directory:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python verify.py
```

The helper validates every file checksum, fixture and tolerance digests, shapes,
finite values, row IDs, and byte equality across all three passes. It replays
the unchanged decision function and requires exact equality to both saved
receipts. A successful verification prints `tier=refused` for both models:
that is the recorded finding, not a failed archive check.

`conformance_snapshot.py` is a byte-for-byte copy of
`anamnesis/extraction/vllm/conformance.py` at the source commit, included with
the repository license. Only NumPy and Pydantic are required; no Anamnesis
installation, vLLM, Torch, Hugging Face access, or GPU is needed.

The companion full evidence archive contains running notes, all per-row capture
receipts, and 8B spectral substrates. Neither archive contains model weights,
authentication files, full raw capture tensors, or auxiliary KNN-LM arrays.
