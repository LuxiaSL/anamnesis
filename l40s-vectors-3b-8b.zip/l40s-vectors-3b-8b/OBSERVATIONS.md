# L40S cross-architecture observation: 3B and 8B

Source commit: `34e7fb6c8e46d229f61f23d28e8675eb89cda9fa`. All shipped acceptance rules remain unchanged.

| Model | Dtype | Rows × features | Repeats identical | Batched identical | Tier | Worst family / ceiling |
| --- | --- | --- | --- | --- | --- | --- |
| 3b | float16 | 44 × 3358 | True | True | refused | attn-spectral: 1.14599× |
| 8b | bfloat16 | 44 × 3414 | True | True | refused | attn-flow: 2.27209× |

## Continuous feature families

Each sigma and ceiling belongs to that model’s calibration. These are descriptive comparisons, not a shared ruler.

| Family | 3B max / ceiling (σ) | 3B multiple | 8B max / ceiling (σ) | 8B multiple |
| --- | --- | ---: | --- | ---: |
| attention | 0.00295411 / 0.00429151 | 0.688361 | 0.0235376 / 0.0557571 | 0.422146 |
| attn-cache | 0.00670152 / 0.018407 | 0.364075 | 0.0538027 / 0.20591 | 0.261292 |
| attn-flow | 0.00967315 / 0.0163684 | 0.590964 | 0.459688 / 0.202319 | 2.27209 |
| attn-head | 0.00926525 / 0.0198673 | 0.466357 | 0.103383 / 0.239012 | 0.432541 |
| attn-spectral | 0.0530981 / 0.0463338 | 1.14599 | 0.308773 / 0.629596 | 0.49043 |
| gate | 0.00947891 / 0.0175297 | 0.540735 | 0.321406 / 0.439949 | 0.730552 |
| keys | 0.0142296 / 0.0278775 | 0.510434 | 0.120804 / 0.511362 | 0.236241 |
| output | 0.0285928 / 0.0328713 | 0.869841 | 0.197133 / 0.357351 | 0.551651 |
| qk | 0.0116718 / 0.02019 | 0.5781 | 0.352978 / 0.214797 | 1.64331 |
| residual | 0.0132797 / 0.0250097 | 0.530981 | 0.246461 / 0.236715 | 1.04117 |
| values | 0.00972395 / 0.0163569 | 0.594486 | 0.21424 / 0.365579 | 0.586029 |

## 3b acceptance details

- row 48: family attn-spectral at 1.15× its recorded maximum
- substrate: maximum row ratio 1.31886 / 2.86977; ordinary median 1.03177 / 1.2442; ordinary tail exceedances 0.
- attention: maximum row ratio 0.219677 / 0.37065; ordinary median 0.117374 / 0.277692; ordinary tail exceedances 0.

Worst normalized family deviation: fixture 48, `spectral_fiedler_L7`, reference 0.874506831169, candidate 0.873535513878.

## 8b acceptance details

- row 66: family attn-flow at 2.27× its recorded maximum
- row 88: row distance outside the recorded ceiling {'substrate': 2.76932671418847, 'attention': 0.30928114459838807}
- row 88: substrate ratio 2.77 in the ordinary stratum exceeds the recorded p99 1.66
- substrate: maximum row ratio 2.76933 / 2.76929; ordinary median 0.974211 / 1.19373; ordinary tail exceedances 1.
- attention: maximum row ratio 0.499214 / 1.07065; ordinary median 0.318649 / 0.908357; ordinary tail exceedances 0.

Worst normalized family deviation: fixture 66, `attn_flow_L28_recency_bias_w3_std`, reference 0.0363534651697, candidate 0.0386566072702.

## Interpretation limits

- Each model uses its own calibration, reference fixtures, and recorded ceilings.
- The 3B lane uses float16 and the 8B lane bfloat16; model and dtype both differ.
- Ordinary-family distribution summaries are descriptive, not replacement gates.
- Two observations do not certify a broader acceptance regime.

Full metrics and provenance: `outputs/cross-architecture-3b-8b.json`.


## Diagnostic details

Fixture 66 accounts for all five 8B continuous-coordinate exceedances: two
attention-flow coordinates, two QK coordinates, and one residual coordinate.
Fixture 88 separately fails the substrate row ceiling and ordinary-row tail
check. Two transition summaries contribute 83.5033% of that row's squared
substrate distance. Both models pass their component median checks.

Making family extremes report-only would not by itself admit the 8B result:
the current fixture-88 row and tail checks would still refuse it. No alternative
acceptance rule is fitted or applied here.

Full details: `outputs/8b-first-pass-coordinate-exceedances.json` and
`outputs/8b-row88-substrate-contributors.json`. The first-pass diagnostics are
confirmed by the full byte-identical repeat/batch check.

## Resources and reproducibility

The unchanged 8B qualification takes about 19m46s from the first capture spec to
the final receipt, including child startup/teardown and excluding checkpoint
download/digest checking. Approximately 14m05s is feature reduction. Weights use
14.99 GiB GPU memory; observed individual-capture usage is approximately 21 GiB.
Two raw individual passes occupy about 35 GiB of scratch disk. GPU memory returns
to zero on completion. See `outputs/8b-phase-timings.json` and `REPORT.md`.

![Maximum family deviations relative to each model's ceiling](outputs/cross-architecture-family-ceilings.png)
