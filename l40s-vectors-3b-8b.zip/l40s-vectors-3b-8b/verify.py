"""CPU-only replay of the archived L40S conformance decisions (Python >=3.11)."""
import hashlib
import json
from pathlib import Path

import numpy as np

from conformance_snapshot import CapturedFixture, FixtureSet, HostFingerprint, decide, Tolerance

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    manifest = json.loads((ROOT / "SHA256SUMS.json").read_text())
    for name, expected in manifest.items():
        actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        require(actual == expected, f"Checksum mismatch: {name}")
    for model, features in (("3b", 3358), ("8b", 3414)):
        directory = ROOT / model
        fixtures = FixtureSet.load(directory / "reference")
        tolerance = Tolerance.model_validate_json((directory / "reference/tolerance.json").read_text())
        saved = json.loads((directory / "conformance.json").read_text())
        fingerprint = HostFingerprint.model_validate(saved["fingerprint"])
        require(fixtures.digest == fingerprint.fixture_digest, f"{model}: fixture digest")
        require(tolerance.digest == fingerprint.tolerance_digest, f"{model}: tolerance digest")
        passes = []
        for name in ("single-first", "single-repeat", "batched"):
            with np.load(directory / f"{name}.npz", allow_pickle=False) as data:
                ids, vectors = data["generation_ids"], data["vectors"]
                require(vectors.shape == (44, features), f"{model}/{name}: shape")
                require(vectors.dtype == np.float32 and np.isfinite(vectors).all(),
                        f"{model}/{name}: finite float32")
                require(len(set(ids.tolist())) == 44, f"{model}/{name}: duplicate IDs")
                require(set(ids.tolist()) == set(fixtures.vectors), f"{model}/{name}: fixture IDs")
                passes.append({int(gid): vector.copy() for gid, vector in zip(ids, vectors)})
        first, repeat, batched = passes
        require(all(first[g].tobytes() == repeat[g].tobytes() == batched[g].tobytes()
                    for g in first), f"{model}: repeat/batch drift")
        receipt = decide(fixtures, tolerance, fingerprint, [
            CapturedFixture(generation_id=g, first=first[g], repeat=repeat[g], batched=batched[g])
            for g in sorted(first)
        ])
        require(receipt.model_dump(mode="json") == saved, f"{model}: receipt differs")
        print(f"{model}: 44 x {features}; all hashes valid; repeat/batch byte-identical; "
              f"receipt reproduced exactly; tier={receipt.tier}; digest={receipt.digest}")
    print("Verification passed. Both saved scientific verdicts remain refused.")


if __name__ == "__main__":
    main()
